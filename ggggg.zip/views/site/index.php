<?php

/* @var $this yii\web\View */


$this->title = 'Aplicacion Del Area De Psicología ';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Bienvenido a la Aplicacion De Psicología</h1>

        <p class="lead">"ISMA-4"</p>

        <p><a class="btn btn-lg btn-success" href="http://localhost:8080/usuarios/create">REGíSTRATE AQUÍ</a></p>
                <p><a class="btn btn-lg btn-success" href="http://localhost:8080/usuarios">VISUALIZAR REGISTRO</a></p>
    </div>

    <body style="background-color:#009000;">
</body>

    <div class="body-content">

        
                